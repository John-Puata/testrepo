# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 19:44:18 2024 

@author: F5598699
"""

import pandas as pd

churn_data = pd.read_csv("Churn_Modelling.csv")
df_churn_data = pd.DataFrame(churn_data)

#print(df_churn_data)

#print(df_churn_data.CustomerId)


