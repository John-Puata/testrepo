# -*- coding: utf-8 -*-
"""
Created on Sat Jun 15 21:09:56 2024

@author: F5598699
"""

import PyPDF2
import json

pdf_file = open('UP Brochure.pdf', 'rb')
read_pdf = PyPDF2.PdfReader(pdf_file)
number_of_pages = len(read_pdf.pages)
page = read_pdf.pages[10]
page_content = page.extract_text()

data = json.dumps(page_content)
print(data)