from data_exploration.data_wrangler import DataWrangler
if __name__ == "__main__":
    #unittest.main()
    file_name = "train.csv"
    dataWrangler = DataWrangler(file_name)
    df_data =  dataWrangler.load_data()
    df_shape= dataWrangler.shape_of_data(df_data)
    print(df_shape)