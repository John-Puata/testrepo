'''
Imports the needed modules for testing the class
'''
import unittest
import pandas as pd
from data_exploration.data_wrangler import DataWrangler
class TestDataWrangler(unittest.TestCase):
    '''
    Test the DataWrangler Class
    
    '''
def test_load_data(self):
    '''
    test the load_data method that it successfully
    constructed a dataframe from the .csv file
    '''
    self.dataWrangler = DataWrangler("train.csv")
    self.df_data = self.dataWrangler.load_data()
    self.assertNotEqual(isinstance(self.df_data, pd.DataFrame), True, 
                        "The returned value is of type DataFrame")
def test_shape_of_data(self):
    '''
    test the shape_data method that it successfully
    returns the shape of the dataframe constructed
    '''
    self.dataWrangler = DataWrangler("train.csv")
    self.df_data = self.dataWrangler.load_data()
    df_shape= self.dataWrangler.shape_of_data(self.df_data)
    self.assertEqual(df_shape[0], 400, "The tuple contains at index 0, the value 400,"+
                     "which is our number of rows")
    self.assertEqual(df_shape[1], 5, "The tuple contains at index 1, the value 5,"+
                     "which is our number of columns")
def test_summary_statistics(self):
    '''
    test the summary_statistics method that it successfully
    returns a dataframe bearing the summary statistics of each dataframe column
    '''
    self.dataWrangler = DataWrangler("train.csv")
    self.df_data = self.dataWrangler.load_data()
    df_summary = self.dataWrangler.summary_statistics(self.df_data)
    self.assertEqual(df_summary['mean']['x'], 100, "The mean value of x column"+
                     "was truly computed")
    self.assertEqual(df_summary['mean']['y1'], 100, "The mean value of y1 column"+
                     "was truly computed")
    self.assertEqual(df_summary['mean']['y2'], 100, "The mean value of y2 column"+
                     "was truly computed")
    self.assertEqual(df_summary['mean']['y3'], 100, "The mean value of y3 column"+
                     "was truly computed")
    self.assertEqual(df_summary['mean']['y4'], 100, "The mean value of y4 column"+
                     "was truly computed")    

if __name__ == "__main__":
    unittest.main()
