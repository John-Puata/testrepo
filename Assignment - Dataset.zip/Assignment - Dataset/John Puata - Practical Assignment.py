# -*- coding: utf-8 -*-
"""
Created on Thu Aug 15 21:42:32 2024

@author: F5598699
"""

import pandas as pd
import openpyxl 
import os

cwd = os.getcwd()
#print(cwd)

data_train = pd.read_excel(r"C:\Users\F5598699\OneDrive - FRG\Documents\Professional Development\MSc Data Science\Programming with Python\Assignment - Dataset\Dataset2\train.csv", engine = "openpyxl")

